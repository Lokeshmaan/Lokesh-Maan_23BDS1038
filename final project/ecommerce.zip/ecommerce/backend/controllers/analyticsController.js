const Purchase = require('../models/Purchase');
const Product = require('../models/Product');

exports.getTotalSales = async (req, res) => {
  try {
    const purchases = await Purchase.find();
    const totalSales = purchases.reduce((sum, p) => sum + p.total, 0);
    res.json({ totalSales });
  } catch (err) {
    res.status(500).json({ message: 'Failed to calculate total sales', error: err.message });
  }
};

exports.getSalesByProduct = async (req, res) => {
  try {
    const purchases = await Purchase.find().populate('items.product');

    const salesMap = {};

    purchases.forEach(purchase => {
      purchase.items.forEach(item => {
        const productId = item.product._id;
        const productName = item.product.name;
        const revenue = item.product.price * item.quantity;

        if (!salesMap[productId]) {
          salesMap[productId] = {
            name: productName,
            totalRevenue: 0
          };
        }

        salesMap[productId].totalRevenue += revenue;
      });
    });

    const salesArray = Object.entries(salesMap).map(([id, data]) => ({
      productId: id,
      name: data.name,
      totalRevenue: data.totalRevenue
    }));

    res.json(salesArray);
  } catch (err) {
    res.status(500).json({ message: 'Failed to calculate sales by product', error: err.message });
  }
};

exports.getTopSellingProducts = async (req, res) => {
  try {
    const purchases = await Purchase.find().populate('items.product');

    const productCount = {};

    purchases.forEach(purchase => {
      purchase.items.forEach(item => {
        const productId = item.product._id;
        const productName = item.product.name;

        if (!productCount[productId]) {
          productCount[productId] = {
            name: productName,
            quantitySold: 0
          };
        }

        productCount[productId].quantitySold += item.quantity;
      });
    });

    const topProducts = Object.entries(productCount)
      .map(([id, data]) => ({
        productId: id,
        name: data.name,
        quantitySold: data.quantitySold
      }))
      .sort((a, b) => b.quantitySold - a.quantitySold)
      .slice(0, 10);

    res.json(topProducts);
  } catch (err) {
    res.status(500).json({ message: 'Failed to get top selling products', error: err.message });
  }
};
