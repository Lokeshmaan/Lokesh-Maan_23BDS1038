const Purchase = require('../models/Purchase');
const Cart = require('../models/Cart');

exports.checkout = async (req, res) => {
  try {
    const cart = await Cart.findOne({ user: req.user._id }).populate('items.product');
    if (!cart || cart.items.length === 0) {
      return res.status(400).json({ message: 'Cart is empty' });
    }

    const total = cart.items.reduce((sum, item) => {
      return sum + item.product.price * item.quantity;
    }, 0);

    const purchase = new Purchase({
      user: req.user._id,
      items: cart.items,
      total
    });

    await purchase.save();
    cart.items = [];
    await cart.save();

    res.status(201).json({ message: 'Checkout successful', purchase });
  } catch (err) {
    res.status(500).json({ message: 'Checkout failed', error: err.message });
  }
};

exports.getUserPurchases = async (req, res) => {
  try {
    const purchases = await Purchase.find({ user: req.user._id }).populate('items.product');
    res.json(purchases);
  } catch (err) {
    res.status(500).json({ message: 'Failed to get purchases', error: err.message });
  }
};

exports.getAllPurchases = async (req, res) => {
  try {
    const purchases = await Purchase.find().populate('user items.product');
    res.json(purchases);
  } catch (err) {
    res.status(500).json({ message: 'Failed to get all purchases', error: err.message });
  }
};
