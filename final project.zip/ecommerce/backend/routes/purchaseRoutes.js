const express = require('express');
const router = express.Router();
const {
  checkout,
  getUserPurchases,
  getAllPurchases
} = require('../controllers/purchaseController');

const { protect, isAdmin } = require('../middleware/authMiddleware');

router.post('/checkout', protect, checkout); // User checkout
router.get('/my', protect, getUserPurchases); // View user's purchases
router.get('/all', protect, isAdmin, getAllPurchases); // Admin view all

module.exports = router;
