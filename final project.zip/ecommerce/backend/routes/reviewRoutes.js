const express = require('express');
const router = express.Router();
const {
  createReview,
  getProductReviews,
  deleteReview
} = require('../controllers/reviewController');
const { protect } = require('../middleware/authMiddleware');

// POST /api/reviews/:productId - Add review
router.post('/:productId', protect, createReview);

// GET /api/reviews/:productId - Get all reviews
router.get('/:productId', getProductReviews);

// DELETE /api/reviews/:productId/:reviewId - Delete a review
router.delete('/:productId/:reviewId', protect, deleteReview);

module.exports = router;
