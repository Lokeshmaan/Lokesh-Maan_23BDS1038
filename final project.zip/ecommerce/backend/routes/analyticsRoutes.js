const express = require('express');
const router = express.Router();
const {
  getTotalSales,
  getSalesByProduct,
  getTopSellingProducts
} = require('../controllers/analyticsController');

const { protect, isAdmin } = require('../middleware/authMiddleware');

router.get('/total-sales', protect, isAdmin, getTotalSales);
router.get('/sales-by-product', protect, isAdmin, getSalesByProduct);
router.get('/top-products', protect, isAdmin, getTopSellingProducts);

module.exports = router;
